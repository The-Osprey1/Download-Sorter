# Download Sorter visual previews

Source snapshot: 513445f4c54b9c89ead87f045fc1add8158a48fd

The original application files are unchanged. Presentation adapters live in work/preview_variants.py.

Use a Python environment with PySide6==6.8.3, Pillow, pytest, and the repository requirements. On this machine the base interpreter is C:/Users/devyn/anaconda3/python.exe. Run work/render_matrix.py, then work/build_gallery.py, from the extracted root. The scripts use their own interpreter for child processes.

All app state for rendering is redirected to work/render-temp before importing the application. The gallery is written to outputs/comparison.html. These adapters produce static snapshots; they are not a production theme switcher.
