"""Run upstream screenshot fixtures with an isolated visual adapter."""
import sys
from pathlib import Path
import importlib.util
import tempfile

tempfile.tempdir = str(Path(__file__).parent.resolve() / 'render-temp')
Path(tempfile.tempdir).mkdir(exist_ok=True)

direction = sys.argv.pop(1)
root = Path(__file__).parent / 'Download-Sorter'
sys.path.insert(0, str(root))
spec = importlib.util.spec_from_file_location('screens', root / 'tools/render_screens.py')
screens = importlib.util.module_from_spec(spec)
spec.loader.exec_module(screens)
import preview_variants
preview_variants.install(direction)
original = screens.Shooter.shoot
original_settle = screens.Shooter.settle

def settle(self, rounds=8):
    original_settle(self, rounds)
    focus = self.app.focusWidget()
    if focus and focus.property('role') == 'nav':
        focus.clearFocus()

screens.Shooter.settle = settle

def prepare(widget, name, size):
    preview_variants.tune(widget, direction, size)
    if name == 'banners':
        widget.setObjectName('previewRoot')
        widget.setStyleSheet(preview_variants.ui_style.stylesheet() + 'QWidget#previewRoot {background:#0D1010;}')
    if name == 'cleanup_scanned':
        widget._remodel_widget._custom_path_edit.setText(r'C:\Users\Devyn\Downloads\Messy')
    if name != 'roles' and widget.focusWidget():
        widget.focusWidget().clearFocus()

def shoot(self, widget, name, size, extra=None):
    prepare(widget, name, size)
    if name == 'roles':
        size = (1160, 940)
    original(self, widget, name, size, extra)
    if name == 'home_running':
        table = widget._home_widget._activity_table
        filename, destination = table.item(0,0), table.item(0,1)
        old_name, old_dest = filename.text(), destination.text()
        filename.setText('IME4030_Final_Project_Manufacturing_Analysis_Revision_12_Reviewed.pdf')
        destination.setText('Documents\\School\\IME 4030\\Final project\\Reviewed submissions')
        filename.setToolTip(filename.text())
        destination.setToolTip(destination.text())
        preview_variants.refresh(widget, direction == 'B', size[0] <= 900)
        original(self, widget, 'home_long_paths', size)
        filename.setText(old_name)
        destination.setText(old_dest)
        preview_variants.refresh(widget, direction == 'B', size[0] <= 900)
    if name == 'dialog_rule_library':
        from PySide6.QtWidgets import QMessageBox
        box = QMessageBox()
        box.setStyleSheet(preview_variants.ui_style.stylesheet())
        box.setWindowTitle('Save your rule changes?')
        box.setText("You changed some rules but didn't save them.")
        box.setInformativeText('Save them now, or close without saving?')
        save = box.addButton('Save changes', QMessageBox.ButtonRole.AcceptRole)
        save.setProperty('role','primary')
        box.addButton("Don't save", QMessageBox.ButtonRole.DestructiveRole)
        box.addButton('Cancel', QMessageBox.ButtonRole.RejectRole)
        box.setDefaultButton(save)
        box.setStyleSheet(preview_variants.ui_style.stylesheet())
        box.show()
        self.settle()
        original(self, box, 'dialog_unsaved_changes', (box.width(),box.height()))
        box.close()

screens.Shooter.shoot = shoot
sys.exit(screens.main())
