from pathlib import Path
import json
import re
from PIL import Image

root=Path(__file__).resolve().parent.parent
out=root/'outputs'
errors=[]
count=0
expected=None
for manifest in out.glob('*/*/manifest.json'):
    entries=json.loads(manifest.read_text())
    states={x['name'] for x in entries}
    if expected is None: expected=states
    if states!=expected: errors.append(f'Unmatched states: {manifest}')
    factor=2 if '200' in manifest.parent.name else 1.5 if '150' in manifest.parent.name else 1
    for entry in entries:
        count+=1
        image=manifest.parent/entry['file']
        if not image.exists() or not entry['saved']: errors.append(f'Missing image: {image}')
        else:
            with Image.open(image) as im:
                physical=tuple(int(x*factor+0.5) for x in entry['actual'])
                if im.size!=physical: errors.append(f'Unexpected pixel size: {image}: {im.size} / {physical}')
        if 'asked' in entry and entry['asked']!=entry['actual']:
            errors.append(f'Window resized: {manifest}: {entry["name"]}')
assert count==312, count
assert not errors, errors
html=(out/'comparison.html').read_text(encoding='utf-8')
script=re.search(r'<script>(.*?)</script>',html,re.S).group(1)
(root/'work/gallery-script.js').write_text(script,encoding='utf-8')
data=json.loads(re.search(r'const screens=(.*?);\n',script).group(1))
assert len(data)==26
for d in ('A','B'):
    for v in ('standard','minimum','scale150','scale200','minimum150','minimum200'):
        for screen in data: assert (out/d/v/(screen['name']+'.png')).is_file()
for filename in ('baseline.png','preview-source.zip','render-results.json'):
    assert (out/filename).is_file()

def luminance(value):
    channels=[int(value[i:i+2],16)/255 for i in (1,3,5)]
    channels=[c/12.92 if c<=.04045 else ((c+.055)/1.055)**2.4 for c in channels]
    return sum(c*w for c,w in zip(channels,(.2126,.7152,.0722)))

pairs=[('A primary text','#EDF3F0','#151A20'),('A secondary text','#A4B0BE','#151A20'),
       ('B primary text','#EDF3F0','#151919'),('B secondary text','#AAB8B1','#151919'),
       ('Primary action text','#0B0D12','#69E6AD'),('Focus outline','#8CB8FF','#1D242C')]
rows=[]
for name,fg,bg in pairs:
    a,b=sorted((luminance(fg),luminance(bg)))
    ratio=(b+.05)/(a+.05)
    assert ratio>=4.5
    rows.append(f'| {name} | {fg} | {bg} | {ratio:.2f}:1 |')
report='''# Download Sorter — preview validation

## Deliverables

- Two native PySide6 presentation variants: A — Refined Mint and B — Dark Workspace.
- 26 matched screen/state previews per direction, at six size/scaling combinations: 312 PNG images.
- Offline comparison gallery with screen selection, scale selection, A/B views, full-size image links, and the original repository Home screenshot.
- Source snapshot and isolated preview adapters in `preview-source.zip`.
- Source commit: `513445f4c54b9c89ead87f045fc1add8158a48fd`.

## Executed checks

- All 12 renderer processes exited successfully. Every image is present and decodes correctly.
- All requested window sizes match the recorded actual sizes. Main: 1040 × 760 and 900 × 640. Setup: 760 × 680 and 720 × 640.
- Physical PNG dimensions match Qt scale factors 1.0, 1.5, and 2.0. Dialogs, notifications, component sheets, and the full Settings capture use their own dimensions.
- The two directions contain the same 26 named states in every size/scaling set.
- All 312 image paths referenced by the gallery data resolve locally.
- Existing UI tests: **51 passed** across `test_ui_foundation.py`, `test_ui_workflows.py`, and `test_layout_fit.py`, using `work/run_ui_checks.py` and PySide6 6.8.3. These tests cover the unchanged underlying components and workflows; they do not certify the preview adapters as production code. Pytest emitted two configuration warnings because the optional timeout plugin was not installed.
- Visual inspection covered all screen types at standard size and minimum size at 200% scaling, with full-resolution spot checks for Home, long paths, notifications, and confirmation dialogs.
- Corrected problems found during review: overlapping destination labels in B, notification-host background, crowded onboarding category choices, and excess vertical space in the compact Home layout.
- Existing long Settings descriptions wrap. Long filenames are elided inside table columns; B shortens deep paths while retaining full native tooltips. Those tooltips cannot be opened from a static PNG.
- Selected navigation states, disabled controls, focus rings, status wording, and four notification tones are visible in the captures. Status is communicated with text as well as color.

## Measured palette contrast

WCAG relative-luminance ratios for representative text/surface pairs and the focus outline. This is a palette check, not a complete accessibility audit.

| Role | Foreground | Background | Contrast |
|---|---|---|---|
'''+ '\n'.join(rows)+'''

## Verification limits

- Browser-based gallery verification could not be completed: localhost navigation returned HTTP 403, and browser automation policy rejected `file:` navigation. No alternative browser surface was used to bypass that restriction. The HTML remains a local deliverable that can be opened by the user.
- Gallery markup, JavaScript syntax, and local image paths were checked separately; browser layout, keyboard operation, and event execution remain unverified.
- Offscreen Qt scaling checks do not replace physical Windows multi-monitor DPI testing.
- Screen-reader testing, full keyboard traversal of both proposed layouts, animation, and complete interactive workflow validation were not performed. These are static comparison previews.
- The compact Rules table and folder lists scroll when content exceeds available height. Long table text may be elided; full content remains available through the existing editing controls/tooltips in a future implementation.

## Isolation and reproduction

The original application and generated `suite_theme.py` are unchanged. All adapters live outside the repository. Render state is redirected to disposable workspace folders before importing the application. No actual Downloads files were sorted.

Extract the source archive and follow its README to render the variants. Production rollout, theme switching, and persistence changes are intentionally outside this visual comparison.
'''
(out/'validation.md').write_text(report,encoding='utf-8')
(out/'validation-results.json').write_text(json.dumps({'images':count,'matched_states':len(expected),'size_errors':errors,'gallery_asset_paths':312,'ui_tests_passed':51},indent=2))
print('PASS: 312 PNGs, 26 matched states, exact sizes and scaling, all gallery image paths, representative contrast pairs.')
