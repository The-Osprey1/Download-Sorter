from pathlib import Path
import json
import shutil
import subprocess
import zipfile
from PIL import Image, ImageOps, ImageDraw

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT/'outputs'
shutil.copy2(ROOT/'work/Download-Sorter/docs/images/home.png', OUT/'baseline.png')
names = [x['name'] for x in json.loads((OUT/'A/standard/manifest.json').read_text())]
titles = {
 'home_running':'Home · Sorting on', 'home_paused':'Home · Paused', 'home_off':'Home · Stopped',
 'home_empty':'Home · Empty', 'home_long_paths':'Home · Long filenames and paths', 'home_row_menu':'Home · File actions',
 'rules_name_rules':'Rules · Name rules', 'rules_file_types':'Rules · File types',
 'rules_sandbox_match':'Rules · Filename matches', 'rules_sandbox_nomatch':'Rules · No match',
 'shell_notice_and_dots':'Rules · Unsaved changes', 'cleanup_empty':'Cleanup · Choose a folder',
 'cleanup_scanned':'Cleanup · Review changes', 'settings':'Settings', 'settings_full':'Settings · Full page',
 'dialog_rule_editor':'Dialog · Edit rule', 'dialog_rule_library':'Dialog · Rule library',
 'dialog_unsaved_changes':'Dialog · Unsaved changes', 'banners':'Notifications · Four states', 'roles':'Components · Focus and disabled states'}
for kind in ('with_folders','no_folders'):
    for i, title in enumerate(('Your folders','How it works','Finish setup'),1):
        titles[f'wizard_{kind}_step{i}'] = f'Setup · {title} · '+('Existing folders' if kind=='with_folders' else 'No folders yet')
order = ['home_running','home_paused','home_off','home_empty','home_long_paths','home_row_menu','rules_name_rules','rules_sandbox_match','rules_sandbox_nomatch','rules_file_types','shell_notice_and_dots','cleanup_empty','cleanup_scanned','settings','settings_full']
order += [x for x in names if x not in order]
data = [{'name':n,'title':titles.get(n,n)} for n in order]

html = r'''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Download Sorter — Design comparison</title>
<style>
:root{color-scheme:dark;--bg:#0b100f;--surface:#141c19;--line:#2e3b35;--text:#edf4ef;--muted:#a9bbb0;--mint:#83e9b5}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--text);font:15px/1.55 "Segoe UI",system-ui,sans-serif}button,select{font:inherit}a{color:var(--mint)}button,select{border:1px solid #46584c;border-radius:7px;padding:9px 13px;background:#18231d;color:var(--text)}button{cursor:pointer}button:hover{background:#293d30}button[aria-pressed=true]{background:var(--mint);color:#092116;border-color:var(--mint)}:focus-visible{outline:3px solid #a0c8ff;outline-offset:3px}.wrap{max-width:1700px;margin:auto;padding:0 36px}header{padding:40px 0 30px;border-bottom:1px solid var(--line)}.kicker{color:var(--mint);font-size:12px;font-weight:600;letter-spacing:.13em;text-transform:uppercase}h1{font-size:clamp(30px,4vw,48px);line-height:1.12;letter-spacing:-1px;margin:12px 0 16px;font-weight:600}header p{max-width:740px;color:var(--muted);margin:0}.summary{display:grid;grid-template-columns:1fr 1fr;gap:40px;padding:26px 0}.summary article{border-left:2px solid var(--mint);padding-left:20px}.summary article:last-child{border-color:#a9bbb0}h2{font-size:20px;margin:0 0 6px}p{margin:0 0 10px}.summary p{color:var(--muted);max-width:650px}.toolbar{display:flex;align-items:end;gap:16px;flex-wrap:wrap;background:#111a16;border:1px solid var(--line);border-radius:10px;padding:16px;margin-bottom:24px}label{display:grid;gap:5px;color:var(--muted);font-size:12px}select{font-size:14px;max-width:100%;min-width:180px}.mode{display:flex;gap:5px;margin-left:auto}.caption{display:flex;justify-content:space-between;align-items:baseline;gap:15px;margin-bottom:16px}.caption p{color:var(--muted);font-size:13px}.grid{display:grid;grid-template-columns:1fr 1fr;gap:24px;align-items:start}.grid.single{grid-template-columns:1fr;max-width:1160px;margin:auto}figure{margin:0;min-width:0}figcaption{display:flex;align-items:center;justify-content:space-between;padding:0 0 10px;font-size:15px}figcaption span{color:var(--muted);font-size:12px}figure img{display:block;width:100%;height:auto;border:1px solid #3a4940;border-radius:9px;background:#101513}figure a{display:block}figure a:focus-visible{outline-offset:5px}.note{padding:12px 0;color:var(--muted);font-size:13px}details{margin:30px 0;border-top:1px solid var(--line);padding-top:22px}summary{cursor:pointer;font-weight:600}details p{max-width:900px;color:var(--muted);margin-top:14px}details img{margin-top:20px;max-width:1040px;width:100%;height:auto}footer{border-top:1px solid var(--line);margin-top:35px;padding:24px 0 40px;color:var(--muted);font-size:13px}footer a{margin-right:20px}.navrow{display:flex;gap:8px;align-items:center}.navrow span{color:var(--muted);font-size:13px}button:disabled{opacity:.4;cursor:default}.badge{font-size:12px;color:var(--muted);margin-left:8px} [hidden]{display:none!important}
@media(max-width:900px){.wrap{padding:0 18px}.grid{grid-template-columns:1fr}.summary{grid-template-columns:1fr;gap:20px}.mode{margin-left:0}.toolbar{align-items:stretch}.toolbar label{flex:1}.caption{display:block}header{padding-top:28px}}
</style></head><body>
<header><div class="wrap"><div class="kicker">Download Sorter / Visual study</div><h1>Same sorter. Two directions.</h1><p>Compare a refined version of the familiar interface with a file-focused dark workspace. These are native PySide6 screen previews using the same sample files, rules, and states.</p></div></header>
<main class="wrap">
<section class="summary" aria-label="Design directions"><article><h2>A — Refined Mint</h2><p>Familiar navigation, clearer type, calmer surfaces, and a more orderly activity list. Best for an incremental refresh with minimal relearning.</p></article><article><h2>B — Dark Workspace</h2><p>Compact status, a larger activity workspace, and actions beside the files. A stronger structural change; the context panel stacks above the list in smaller windows.</p></article></section>
<section class="toolbar" aria-label="Comparison controls"><label>Screen and state<select id="screen"></select></label><label>Window size and display scale<select id="size"><option value="standard">Standard · 100%</option><option value="minimum">Minimum · 100%</option><option value="scale150">Standard · 150%</option><option value="scale200">Standard · 200%</option><option value="minimum150">Minimum · 150%</option><option value="minimum200">Minimum · 200%</option></select></label><div class="mode" aria-label="View"><button type="button" data-mode="both" aria-pressed="true">Side by side</button><button type="button" data-mode="A" aria-pressed="false">A only</button><button type="button" data-mode="B" aria-pressed="false">B only</button></div></section>
<div class="caption"><div><h2 id="title">Home · Sorting on</h2><p id="description"></p></div><div class="navrow"><button id="prev" aria-label="Previous screen">←</button><span id="count"></span><button id="next" aria-label="Next screen">→</button></div></div>
<section class="grid" id="grid" aria-label="Screen previews"><figure id="figureA"><figcaption><strong>A — Refined Mint</strong><span>Open image for full size ↗</span></figcaption><a id="linkA" target="_blank" rel="noopener"><img id="imageA" alt=""></a></figure><figure id="figureB"><figcaption><strong>B — Dark Workspace</strong><span>Open image for full size ↗</span></figcaption><a id="linkB" target="_blank" rel="noopener"><img id="imageB" alt=""></a></figure></section>
<p class="note" id="note" aria-live="polite"></p>
<details><summary>Original Home screen — repository baseline</summary><p>The baseline is the screenshot published in the repository. Its sample files and app version differ from the new rendered previews; A and B use matching current fixtures.</p><a href="baseline.png" target="_blank" rel="noopener"><img src="baseline.png" alt="Original Download Sorter Home screenshot from the repository" loading="lazy"></a></details>
<details><summary>What changed, and what to compare</summary><p><strong>Home:</strong> A preserves the status card. B uses a slim status strip and a side panel; compare the amount of activity visible and the reach to sort, pause, and undo.</p><p><strong>Rules:</strong> A keeps filename testing beneath the rules. B brings it above the ordered table for quicker feedback. Rule precedence is unchanged.</p><p><strong>Cleanup and Settings:</strong> B adds step labels to cleanup and a compact Settings section index. Both preserve the current options, use consistent spacing, and wrap long descriptions.</p><p><strong>Setup and dialogs:</strong> A refines the existing structure. B adds a progress bar and tighter mascot area. Shared controls carry the same visual language across each direction.</p><p><strong>Tradeoff:</strong> B provides more activity height at the standard size but gives destinations less horizontal room. At the minimum size its actions stack above the list. A remains the more familiar, broadly balanced layout.</p></details>
<details><summary>Verification and preview limitations</summary><p>Both concepts were rendered at the standard and minimum window sizes with Qt scale factors of 1, 1.5, and 2. Long paths, empty states, paused/stopped sorting, unsaved changes, and notification states are included. See the validation report for exact results and remaining limits.</p><p>These are static design previews, not two released versions of the application. Image controls do not operate on files. Offscreen scaling checks do not replace a physical multi-monitor DPI test. Screen-reader behavior and complete interactive flows have not been certified.</p></details>
</main><footer><div class="wrap"><p>Built from the existing PySide6 interface. Preview adapters are separate from production source.</p><a href="validation.md">Validation report</a><a href="preview-source.zip">Reproducible preview source</a><a href="render-results.json">Render results</a></div></footer>
<script>
const screens=__DATA__;
const screen=document.getElementById('screen'),size=document.getElementById('size');let mode='both';
screens.forEach(s=>screen.add(new Option(s.title,s.name)));
function update(){const s=screens[screen.selectedIndex],variant=size.value;document.getElementById('title').textContent=s.title;document.getElementById('count').textContent=`${screen.selectedIndex+1} / ${screens.length}`;document.getElementById('prev').disabled=screen.selectedIndex===0;document.getElementById('next').disabled=screen.selectedIndex===screens.length-1;document.getElementById('grid').classList.toggle('single',mode!=='both');for(const d of ['A','B']){const url=`${d}/${variant}/${s.name}.png`;document.getElementById('figure'+d).hidden=mode!=='both'&&mode!==d;document.getElementById('image'+d).src=url;document.getElementById('image'+d).alt=`${d==='A'?'Refined Mint':'Dark Workspace'} — ${s.title} — ${size.options[size.selectedIndex].text}`;document.getElementById('link'+d).href=url;}document.getElementById('description').textContent=s.name.startsWith('wizard')?'Setup: 760 × 680 standard / 720 × 640 minimum.':s.name.startsWith('dialog')||s.name==='banners'||s.name==='roles'||s.name==='home_row_menu'?'This surface has its own size; display scaling still applies.':s.name==='settings_full'?'Extended-height capture showing every Settings section.':'Main window: 1040 × 760 standard / 900 × 640 minimum.';document.getElementById('note').textContent=s.name==='home_long_paths'?'Stress case: long text is contained in table columns. Full filenames and paths remain available in the native control tooltips; tooltips are not interactive in these images.':'Select A only or B only for a larger preview, or open either image at full resolution.';history.replaceState(null,'',`#${s.name}`);}
screen.addEventListener('change',update);size.addEventListener('change',update);document.querySelectorAll('[data-mode]').forEach(b=>b.addEventListener('click',()=>{mode=b.dataset.mode;document.querySelectorAll('[data-mode]').forEach(x=>x.setAttribute('aria-pressed',String(x===b)));update();}));document.getElementById('prev').onclick=()=>{screen.selectedIndex--;update()};document.getElementById('next').onclick=()=>{screen.selectedIndex++;update()};const hash=location.hash.slice(1);if(screens.some(s=>s.name===hash))screen.value=hash;update();
</script></body></html>'''
(OUT/'comparison.html').write_text(html.replace('__DATA__',json.dumps(data)),encoding='utf-8')

# Contact sheets are QA intermediates, not user-facing deliverables.
qa=ROOT/'work/qa'
qa.mkdir(exist_ok=True)
for d in ('A','B'):
    for variant in ('standard','minimum200'):
        for start in range(0,len(order),6):
            sheet=Image.new('RGB',(1560,1320),'#202020')
            draw=ImageDraw.Draw(sheet)
            for i,name in enumerate(order[start:start+6]):
                path=OUT/d/variant/(name+'.png')
                if not path.exists(): continue
                tile=ImageOps.contain(Image.open(path),(780,400))
                x,y=(i%2)*780,(i//2)*440
                sheet.paste(tile,(x,y+30))
                draw.text((x+12,y+8),f'{d} / {variant} / {name}',fill='white')
            sheet.save(qa/f'{d}-{variant}-{start//6}.jpg')

repo=ROOT/'work/Download-Sorter'
files=(subprocess.check_output(['git','ls-files'],cwd=repo,text=True).splitlines()
       if (repo/'.git').exists() else [str(p.relative_to(repo)) for p in repo.rglob('*')
       if p.is_file() and not any(x in p.parts for x in ('__pycache__','.pytest_cache'))])
with zipfile.ZipFile(OUT/'preview-source.zip','w',zipfile.ZIP_DEFLATED) as z:
    for rel in files:
        path=repo/rel
        if path.is_file(): z.write(path, 'work/Download-Sorter/'+rel)
    for name in ('preview_variants.py','render_comparison.py','render_matrix.py','build_gallery.py','run_ui_checks.py','validate_outputs.py'):
        z.write(ROOT/'work'/name,'work/'+name)
    z.writestr('README.md', '''# Download Sorter visual previews\n\nSource snapshot: 513445f4c54b9c89ead87f045fc1add8158a48fd\n\nThe original application files are unchanged. Presentation adapters live in work/preview_variants.py.\n\nUse a Python environment with PySide6==6.8.3, Pillow, pytest, and the repository requirements. On this machine the base interpreter is C:/Users/devyn/anaconda3/python.exe. Run work/render_matrix.py, then work/build_gallery.py, from the extracted root. The scripts use their own interpreter for child processes.\n\nAll app state for rendering is redirected to work/render-temp before importing the application. The gallery is written to outputs/comparison.html. These adapters produce static snapshots; they are not a production theme switcher.\n''')
print(f'Gallery: {len(order)} matched states; source archive and QA sheets created.')
