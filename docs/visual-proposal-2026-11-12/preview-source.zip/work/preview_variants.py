"""Isolated presentation adapters; never imported by the production application."""
from PySide6.QtCore import Qt
from PySide6.QtGui import QColor, QIcon
from PySide6.QtWidgets import (QWidget, QLabel, QPushButton, QCheckBox, QFrame,
    QVBoxLayout, QHBoxLayout, QBoxLayout, QScrollArea, QTableWidget, QHeaderView,
    QSizePolicy, QProgressBar)
import ui_style
import onboarding
import rules_manager

BASE_STYLE = ui_style.stylesheet

def install(direction):
    bold = direction == 'B'
    palette = dict(canvas='#0C0F13', surface='#151A20', raised='#1D242C', border='#303B45', muted='#A4B0BE')
    if bold:
        palette.update(canvas='#0D1010', surface='#151919', raised='#202626', border='#35403D', muted='#AAB8B1')
    p = palette
    css = f'''
    QWidget {{ font-size:14px; color:#EDF3F0; }}
    QDialog, QStackedWidget, QStackedWidget > QWidget {{ background:{p['canvas']}; }}
    QLabel[role="title"] {{ font-size:24px; font-weight:600; }}
    QLabel[role="section"] {{ font-size:16px; font-weight:600; }}
    QLabel[role="muted"], QLabel[role="caption"] {{ color:{p['muted']}; }}
    QLabel[role="caption"] {{ font-size:12px; }}
    QFrame#card {{ background:{p['surface']}; border:1px solid {p['border']}; border-radius:{6 if bold else 12}px; }}
    QFrame#card[hero="true"], QFrame#card[tone="success"] {{ background:{p['surface']}; border-color:{p['border']}; }}
    QFrame#sidebar {{ background:{'#111515' if bold else '#11171D'}; border-right:1px solid {p['border']}; }}
    QPushButton, QToolButton {{ padding:8px 12px; border-radius:{5 if bold else 8}px; }}
    QPushButton[role="nav"] {{ padding:12px 10px; border:1px solid transparent; font-size:14px; }}
    QPushButton[role="nav"]:checked {{ background:#20332C; color:#8CF0BF; border-left:3px solid #69E6AD; }}
    QPushButton:focus, QToolButton:focus, QPushButton[role="nav"]:focus {{ border:2px solid #8CB8FF; }}
    QPushButton[role="primary"]:focus {{ border:2px solid #FFFFFF; }}
    QLineEdit, QComboBox {{ padding:8px 10px; border-color:{p['border']}; }}
    QTableWidget, QListWidget, QTreeWidget {{ background:{p['surface']}; border-color:{p['border']}; border-radius:{4 if bold else 10}px; }}
    QHeaderView::section {{ background:{p['raised']}; color:{p['muted']}; padding:10px 8px; }}
    QTableWidget::item {{ border-bottom:1px solid {p['raised']}; padding:7px 8px; }}
    QFrame#workspaceContext {{ background:{p['surface']}; border:1px solid {p['border']}; border-radius:6px; }}
    QLabel[role="eyebrow"] {{ color:#91A79B; font-size:11px; font-weight:600; }}
    QFrame#statusStrip {{ background:#16231C; border-left:3px solid #69E6AD; border-radius:4px; }}
    QFrame#statusStrip[tone="warning"] {{ background:#2A2118; border-color:#F5AD62; }}
    QFrame#statusStrip[tone="neutral"] {{ background:#202626; border-color:#AAB8B1; }}
    QFrame#sectionIndex {{ background:#151919; border-bottom:1px solid #35403D; }}
    '''
    ui_style.stylesheet = lambda: BASE_STYLE() + css

def label(text, role=None):
    return ui_style.label(text, role, wrap=True)

def wrap_checks(widget):
    """Preserve existing checkbox objects/signals; separate wrapping labels."""
    for check in widget.findChildren(QCheckBox):
        text = check.text()
        if not text or len(text) < 45:
            continue
        parent = check.parentWidget()
        layout = parent.layout() if parent else None
        if not layout or layout.indexOf(check) < 0:
            continue
        index = layout.indexOf(check)
        layout.removeWidget(check)
        row = QWidget()
        line = QHBoxLayout(row)
        line.setContentsMargins(0, 3, 0, 3)
        line.setSpacing(12)
        check.setAccessibleName(text)
        check.setText('')
        check.setProperty('role', 'switch')
        line.addWidget(check, 0, Qt.AlignmentFlag.AlignTop)
        caption = label(text)
        caption.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        caption.setBuddy(check)
        line.addWidget(caption, 1)
        layout.insertWidget(index, row)

def layout_home(home, bold, narrow):
    home._watched_folder_text = lambda: 'your Downloads folder'
    home.refresh_status()
    home._refresh_timer.stop()
    table = home._activity_table
    table.setColumnWidth(1, 172 if not bold else 155)
    table.setColumnWidth(2, 95)
    table.setColumnWidth(3, 76)
    table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
    table.verticalHeader().setDefaultSectionSize(48)
    home._filter_edit.setFixedWidth(210)
    home._empty_hint_lbl.setWordWrap(True)
    if not bold:
        hero = home._status_card.layout()
        hero.setContentsMargins(20, 16, 20, 16)
        # Four full-text actions need a separate second row at the minimum width.
        actions = hero.itemAt(hero.count()-1).layout()
        actions.removeWidget(home._btn_open_downloads)
        feed = home.layout().itemAt(5).layout()
        feed.insertWidget(2, home._btn_open_downloads)
        return
    root = home.layout()
    feed = root.takeAt(5).layout()
    activity = root.takeAt(5).layout()
    root.removeWidget(home._status_card)
    home._status_card.hide()
    strip = QFrame()
    strip.setObjectName('statusStrip')
    strip_layout = QHBoxLayout(strip)
    strip_layout.setContentsMargins(14, 12, 14, 12)
    strip_layout.addWidget(home._status_dot)
    strip_layout.addWidget(home._status_badge)
    strip_layout.addStretch()
    strip_layout.addWidget(home._files_today_lbl)
    root.insertWidget(1, strip)
    home._preview_strip = strip
    context = QFrame()
    context.setObjectName('workspaceContext')
    context_layout = QVBoxLayout(context)
    context_layout.setContentsMargins(16, 16, 16, 16)
    context_layout.setSpacing(12)
    context_layout.addWidget(label('WATCHED FOLDER', 'eyebrow'))
    context_layout.addWidget(label('Downloads', 'section'))
    context_layout.addWidget(home._status_desc_lbl)
    if narrow:
        context_layout.setContentsMargins(12, 10, 12, 10)
        context_layout.setSpacing(8)
        eyebrow = context_layout.takeAt(0).widget()
        eyebrow.hide()
        title = context_layout.takeAt(0).widget()
        heading = QHBoxLayout()
        heading.addWidget(title)
        heading.addStretch()
        heading.addWidget(home._btn_open_downloads)
        context_layout.insertLayout(0, heading)
        row = QHBoxLayout()
        for btn in (home._btn_sort_now, home._btn_undo_last, home._btn_pause_resume):
            row.addWidget(btn)
        context_layout.addLayout(row)
    else:
        context.setFixedWidth(214)
        for btn in (home._btn_sort_now, home._btn_pause_resume, home._btn_undo_last, home._btn_open_downloads):
            context_layout.addWidget(btn)
        context_layout.addStretch()
    context_layout.addWidget(home._waiting_lbl)
    content = QWidget()
    col = QVBoxLayout(content)
    col.setContentsMargins(0, 0, 0, 0)
    col.setSpacing(16)
    col.addLayout(feed)
    col.addLayout(activity, 1)
    if narrow:
        root.addWidget(context)
        root.addWidget(content, 1)
    else:
        workspace = QHBoxLayout()
        workspace.setSpacing(20)
        workspace.addWidget(content, 1)
        workspace.addWidget(context)
        root.addLayout(workspace, 1)
        # In the narrower activity area, show the time beneath each destination.
        table.setColumnHidden(2, True)
        table.setColumnWidth(1, 155)
        table.setColumnWidth(3, 72)
        table.verticalHeader().setDefaultSectionSize(64)
    home._preview_context = context

def tune(widget, direction, size):
    bold = direction == 'B'
    narrow = size[0] <= 900
    if getattr(widget, '_preview_tuned', False):
        refresh(widget, bold, narrow)
        return
    widget._preview_tuned = True
    wrap_checks(widget)
    if isinstance(widget, rules_manager.RulesManagerDialog):
        widget._sidebar.setFixedWidth(184 if bold else 208)
        widget._sidebar.layout().setContentsMargins(12, 24, 12, 16)
        for lbl in widget._sidebar.findChildren(QLabel):
            if lbl.text() == 'Download Sorter':
                lbl.setText('Download\nSorter' if bold else 'Download Sorter')
                lbl.setStyleSheet('font-size:14px; font-weight:600;')
        if bold:
            widget._nav_buttons['cleanup'].setText('Clean up')
        for i in range(widget._view_stack.count()):
            widget._view_stack.widget(i).layout().setContentsMargins(24, 24, 24, 24)
        layout_home(widget._home_widget, bold, narrow)
        if bold:
            rules = widget._customize_container.layout()
            rules.removeWidget(widget._sandbox)
            rules.insertWidget(1, widget._sandbox)
            cleanup = widget._remodel_widget.layout()
            step = label('01  CHOOSE FOLDER     /     02  REVIEW CHANGES     /     03  APPLY', 'eyebrow')
            cleanup.insertWidget(1, step)
            settings = widget._settings_widget
            scroll = settings.findChild(QScrollArea)
            index = QFrame()
            index.setObjectName('sectionIndex')
            row = QHBoxLayout(index)
            row.setContentsMargins(4, 0, 4, 8)
            row.setSpacing(0)
            for title, short in [('Your folders and starter rules','Setup'), ('Windows','Windows'), ('Zip files','Zip files'), ('Folders','Folders'), ('Extra options','Extras'), ('Learning','Learning'), ('About','About')]:
                btn = ui_style.button(short, 'ghost')
                btn.setStyleSheet('font-size:12px; padding:8px 6px;')
                target = next((x for x in scroll.findChildren(QLabel) if x.text() == title), None)
                if target:
                    btn.clicked.connect(lambda checked=False, t=target: scroll.ensureWidgetVisible(t))
                row.addWidget(btn)
            settings.layout().insertWidget(0, index)
        # Remove the minimum-size pressure of the long profile option.
        widget._settings_widget._persona_combo.setMinimumWidth(180)
        widget._settings_widget._btn_rerun_tour.setStyleSheet('padding:8px; font-size:12px;')
    elif isinstance(widget, onboarding.WelcomeWizardDialog):
        widget.layout().setContentsMargins(24, 24, 24, 20)
        # Keep the category grid legible when existing folders also occupy step 1.
        for check in widget._category_checks.values():
            check.setMinimumHeight(24)
        first = widget._stack.widget(0)
        current = widget._stack.currentIndex()
        widget._stack.removeWidget(first)
        page_scroll = QScrollArea()
        page_scroll.setWidgetResizable(True)
        page_scroll.setFrameShape(QFrame.Shape.NoFrame)
        page_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        page_scroll.setWidget(first)
        widget._stack.insertWidget(0, page_scroll)
        widget._stack.setCurrentIndex(current)
        if bold:
            bar = QProgressBar()
            bar.setRange(0, 3)
            bar.setValue(widget._current_step + 1)
            bar.setTextVisible(False)
            bar.setFixedHeight(4)
            widget.layout().insertWidget(1, bar)
            widget._preview_progress = bar
            widget._mascot_widget.setFixedSize(64, 64)
    refresh(widget, bold, narrow)

def refresh(widget, bold, narrow):
    if hasattr(widget, '_preview_progress'):
        widget._preview_progress.setValue(widget._current_step + 1)
    if not isinstance(widget, rules_manager.RulesManagerDialog):
        return
    home = widget._home_widget
    if bold:
        state = home._last_state
        home._preview_strip.setProperty('tone', 'warning' if state == 'paused' else 'neutral' if state == 'stopped' else 'success')
        home._preview_strip.style().unpolish(home._preview_strip)
        home._preview_strip.style().polish(home._preview_strip)
        if not narrow:
            table = home._activity_table
            for r in range(table.rowCount()):
                item, time_item = table.item(r, 1), table.item(r, 2)
                if item and time_item:
                    import html
                    path = item.text().split('\n')[0].replace('\\', ' / ')
                    if len(path) > 45:
                        parts = path.split(' / ')
                        path = parts[0] + ' / … / ' + parts[-1]
                    cell = QLabel('<span style="color:#D8E4DC">' + html.escape(path) + '</span><br><span style="color:#AAB8B1">' + html.escape(time_item.text()) + '</span>')
                    cell.setWordWrap(True)
                    cell.setContentsMargins(8, 3, 8, 3)
                    cell.setToolTip(item.toolTip() or item.text())
                    cell.setStyleSheet('font-size:12px;')
                    item.setForeground(QColor('transparent'))
                    item.setIcon(QIcon())
                    old = table.cellWidget(r, 1)
                    if old:
                        old.hide()
                    table.setCellWidget(r, 1, cell)
    # Stable display wording avoids leaking throwaway absolute paths into screenshots.
    if home._last_state == 'running':
        home._status_desc_lbl.setText('New downloads are filed automatically a few seconds after they finish downloading.')

