from pathlib import Path
import os
import sys
import tempfile
root = Path(__file__).resolve().parent
state = root/'test-state'
state.mkdir(exist_ok=True)
tempfile.tempdir = str(state)
os.environ['LOCALAPPDATA'] = str(state/'appdata')
os.environ['USERPROFILE'] = str(state/'profile')
os.environ['QT_QPA_PLATFORM'] = 'offscreen'
os.environ['QT_QPA_FONTDIR'] = r'C:\Windows\Fonts'
os.environ['DOWNLOAD_SORTER_NO_UPDATE_CHECK'] = '1'
sys.path.insert(0,str(root/'Download-Sorter'))
os.chdir(root/'Download-Sorter')
import pytest
sys.exit(pytest.main(['-q','tests/test_ui_foundation.py','tests/test_ui_workflows.py','tests/test_layout_fit.py','--basetemp',str(state/'pytest-run')]))
