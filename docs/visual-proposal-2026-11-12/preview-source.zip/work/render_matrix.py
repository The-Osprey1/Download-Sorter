from pathlib import Path
import subprocess
import sys
import json
from concurrent.futures import ThreadPoolExecutor

ROOT = Path(__file__).resolve().parent.parent
jobs = [(d, variant, scale, minimum) for d in ('A','B') for variant,scale,minimum in (
    ('standard',1,False),('minimum',1,True),('scale150',1.5,False),('scale200',2,False),
    ('minimum150',1.5,True),('minimum200',2,True))]

def run(job):
    d, variant, scale, minimum = job
    out = ROOT/'outputs'/d/variant
    out.mkdir(parents=True, exist_ok=True)
    cmd = [sys.executable, str(ROOT/'work/render_comparison.py'), d, '--out', str(out), '--scale', str(scale)]
    if minimum: cmd.append('--min')
    result = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True)
    (out/'render.log').write_text(result.stdout + result.stderr, encoding='utf-8')
    print(f'{d}/{variant}: exit {result.returncode}', flush=True)
    return {'direction':d,'variant':variant,'returncode':result.returncode}

with ThreadPoolExecutor(max_workers=2) as pool:
    results = list(pool.map(run,jobs))
(ROOT/'outputs/render-results.json').write_text(json.dumps(results,indent=2))
sys.exit(any(x['returncode'] for x in results))
