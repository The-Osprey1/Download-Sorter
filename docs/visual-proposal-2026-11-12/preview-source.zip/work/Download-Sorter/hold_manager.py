"""3MF Grace-Period Hold & MakerWorld Overhaul Manager for Download Sorter.

Holds active .3mf files in Downloads for a configurable grace period (default 7 days)
without moving them, preserving Bambu Studio / OrcaSlicer project shortcuts, recent
file lists, and direct saves.  Surfaces instant preview ribbons with embedded plate
thumbnails, and provides 1-click 'File now' and 'Keep here' controls.
"""

from __future__ import annotations

from contextlib import contextmanager
import copy
import json
import logging
import os
from pathlib import Path
import re
import shutil
import sys
import tempfile
import threading
import time
from typing import Iterable

if sys.platform == "win32":
    import ctypes
    from ctypes import wintypes

import safe_ops
import sorter

SCHEMA = 1
STATE_NAME = "held_files.json"
DEFAULT_HOLD_DAYS = 7
DEFAULT_MAX_HELD = 15
DEFAULT_SLICERS = ["bambu-studio.exe", "bambu-studio-worker.exe", "orca-slicer.exe", "prusa-slicer.exe"]

_THREAD_LOCK = threading.RLock()


def state_file() -> Path:
    return Path(sorter.LOG_DIR) / STATE_NAME


@contextmanager
def state_lock(timeout: float = 2.0):
    """Cross-process file lock protecting held_files.json."""
    with _THREAD_LOCK:
        handle = None
        locked = False
        msvcrt = None
        if sys.platform == "win32":
            try:
                import msvcrt

                lock_path = state_file().with_suffix(".lock")
                lock_path.parent.mkdir(parents=True, exist_ok=True)
                deadline = time.monotonic() + timeout
                while time.monotonic() < deadline:
                    try:
                        handle = open(lock_path, "a+b")
                        msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
                        locked = True
                        break
                    except (BlockingIOError, OSError):
                        if handle:
                            try:
                                handle.close()
                            except Exception:
                                pass
                            handle = None
                        time.sleep(0.02)
            except Exception as exc:
                logging.debug("Hold state lock fallback: %s", exc)
        try:
            yield
        finally:
            if locked and handle and msvcrt:
                try:
                    handle.seek(0)
                    msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
                except Exception:
                    pass
            if handle:
                try:
                    handle.close()
                except Exception:
                    pass


def read_state() -> dict:
    target = state_file()
    if not target.exists():
        return {"schema": SCHEMA, "held": {}}
    try:
        data = json.loads(target.read_text(encoding="utf-8"))
        if isinstance(data, dict) and "held" in data:
            return data
    except Exception as exc:
        logging.debug("Failed reading held_files.json: %s", exc)
    return {"schema": SCHEMA, "held": {}}


def write_state(data: dict) -> None:
    target = state_file()
    target.parent.mkdir(parents=True, exist_ok=True)
    temp = target.with_suffix(".tmp")
    try:
        temp.write_text(json.dumps(data, indent=2), encoding="utf-8")
        temp.replace(target)
    except Exception as exc:
        logging.debug("Failed writing held_files.json: %s", exc)
        try:
            if temp.exists():
                temp.unlink()
        except Exception:
            pass


def is_slicer_running(slicer_names: Iterable[str] | None = None) -> bool:
    """Check if any 3D slicer executable is currently active in the process table."""
    if sys.platform != "win32":
        return False

    targets = {s.lower() for s in (slicer_names or DEFAULT_SLICERS)}
    try:
        TH32CS_SNAPPROCESS = 0x00000002

        class PROCESSENTRY32(ctypes.Structure):
            _fields_ = [
                ("dwSize", wintypes.DWORD),
                ("cntUsage", wintypes.DWORD),
                ("th32ProcessID", wintypes.DWORD),
                ("th32DefaultHeapID", ctypes.POINTER(wintypes.ULONG)),
                ("th32ModuleID", wintypes.DWORD),
                ("cntThreads", wintypes.DWORD),
                ("th32ParentProcessID", wintypes.DWORD),
                ("pcPriClassBase", wintypes.LONG),
                ("dwFlags", wintypes.DWORD),
                ("szExeFile", ctypes.c_wchar * 260),
            ]

        hSnapshot = ctypes.windll.kernel32.CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0)
        pe = PROCESSENTRY32()
        pe.dwSize = ctypes.sizeof(PROCESSENTRY32)
        found = False
        if ctypes.windll.kernel32.Process32FirstW(hSnapshot, ctypes.byref(pe)):
            while True:
                exe = pe.szExeFile.lower()
                if exe in targets:
                    found = True
                    break
                if not ctypes.windll.kernel32.Process32NextW(hSnapshot, ctypes.byref(pe)):
                    break
        ctypes.windll.kernel32.CloseHandle(hSnapshot)
        return found
    except Exception as exc:
        logging.debug("Slicer process check error: %s", exc)
        return False


def is_held(path: Path | str) -> bool:
    resolved = str(Path(path).resolve())
    with state_lock():
        state = read_state()
        return resolved in state.get("held", {})


def is_keep_here(path: Path | str) -> bool:
    resolved = str(Path(path).resolve())
    with state_lock():
        state = read_state()
        rec = state.get("held", {}).get(resolved)
        return bool(rec and rec.get("keep_here"))


def get_held(path: Path | str) -> dict | None:
    resolved = str(Path(path).resolve())
    with state_lock():
        state = read_state()
        rec = state.get("held", {}).get(resolved)
        return dict(rec) if rec else None


def get_all_held() -> list[dict]:
    with state_lock():
        state = read_state()
        return list(state.get("held", {}).values())


def hold_period_over(path: Path | str, config: dict, now: float | None = None) -> bool:
    """True when ``path`` has been in place for longer than the hold lasts.

    The hold counts from when the file arrived, not from when Download Sorter first
    looked at it. A file that sat in Downloads for ``hold_days`` or more before that
    (an old file found by a sweep, or found again after a reinstall that forgot the
    holds) has nothing left to wait for, so it is filed instead of held again.
    """
    hold_days = float(config.get("hold", {}).get("hold_days", DEFAULT_HOLD_DAYS))
    cur_time = time.time() if now is None else float(now)
    arrived = sorter.arrival_time(Path(path))
    return arrived is not None and arrived + hold_days * 86400.0 <= cur_time


# What ``register_hold`` found.
HOLD_NOT_HELD = "not held"    # holds are off, or the file waited long enough: the caller files it
HOLD_KEPT_HERE = "kept here"  # the user chose "Keep here" for it
HOLD_UNCHANGED = "unchanged"  # held already, and the file is the same: its schedule stays
HOLD_NEW = "new"              # held now: a new file, or one that changed since (a new download of it)


def register_hold(
    path: Path | str,
    config: dict,
    planned_dest: Path | str,
    meta: dict | None = None,
    now: float | None = None,
) -> str:
    """Hold a .3mf file in Downloads for the grace period, and say what that found (a ``HOLD_`` value).

    A caller that tells the user about a hold does it for ``HOLD_NEW`` only. A file that is found
    again unchanged (by every sweep, at every start-up, by a second event for the same download)
    is held already, and was announced when it was first held.
    """
    p = Path(path).resolve()
    if not p.exists() or not p.is_file():
        return HOLD_NOT_HELD

    hold_cfg = config.get("hold", {})
    if not hold_cfg.get("enabled", True):
        return HOLD_NOT_HELD

    hold_days = float(hold_cfg.get("hold_days", DEFAULT_HOLD_DAYS))
    max_held = int(hold_cfg.get("max_held", DEFAULT_MAX_HELD))
    cur_time = time.time() if now is None else float(now)

    try:
        st = p.stat()
        mtime = st.st_mtime
        size = st.st_size
    except OSError:
        return HOLD_NOT_HELD

    key = str(p)
    with state_lock():
        state = read_state()
        held = state.setdefault("held", {})

        # If already marked keep_here, respect it
        if key in held and held[key].get("keep_here"):
            return HOLD_KEPT_HERE

        # Already held and unchanged (e.g. the startup sweep sees it again): keep the
        # existing schedule instead of pushing the release out by another hold period.
        existing = held.get(key)
        if existing and int(existing.get("size", -1)) == size and abs(float(existing.get("mtime", 0)) - mtime) <= 2.0:
            return HOLD_UNCHANGED

        if max_held < 1 or hold_period_over(p, config, cur_time):
            return HOLD_NOT_HELD

        # At most ``max_held`` files wait at once. The one closest to its release is filed
        # instead of being forgotten: it is made due now, and the normal release moves it
        # (waiting for a slicer or an open file as usual). Dropping its record left the file
        # in place with no hold and nothing that would ever release it.
        if key not in held:
            waiting = sorted(
                (k for k, rec in held.items()
                 if not rec.get("keep_here") and float(rec.get("release_at", 0)) > cur_time),
                key=lambda k: float(held[k].get("release_at", 0)),
            )
            for old in waiting[: max(0, len(waiting) - max_held + 1)]:
                held[old]["release_at"] = cur_time
                logging.info("3MF hold limit (%d) reached: %s will be filed now", max_held, held[old].get("filename", old))

        # The hold runs from when the file arrived, not from when it was first noticed.
        arrived = sorter.arrival_time(p)
        release_at = (cur_time if arrived is None else min(cur_time, arrived)) + (hold_days * 86400.0)
        mw_meta = (meta or {}).get("makerworld_meta", {}) if meta else {}

        held[key] = {
            "path": key,
            "filename": p.name,
            "size": size,
            "mtime": mtime,
            "first_seen": cur_time,
            "release_at": release_at,
            "hold_days": hold_days,
            "planned_dest": str(Path(planned_dest).resolve()),
            "makerworld_meta": mw_meta,
            "keep_here": False,
        }
        write_state(state)

    logging.info("3MF Hold registered: %s (holding until %s)", p.name, time.ctime(release_at))
    return HOLD_NEW


def hold_file(
    path: Path | str,
    config: dict,
    planned_dest: Path | str,
    meta: dict | None = None,
    now: float | None = None,
) -> bool:
    """Register a .3mf file for grace-period hold in Downloads.

    Returns False when the file is not to be held, and the caller files it: holds are
    off, or the file has been in place longer than the hold lasts (``hold_period_over``).
    """
    return register_hold(path, config, planned_dest, meta=meta, now=now) != HOLD_NOT_HELD


def keep_here(path: Path | str) -> bool:
    """User chosen override: keep this .3mf file permanently in Downloads."""
    p = Path(path).resolve()
    key = str(p)
    with state_lock():
        state = read_state()
        held = state.setdefault("held", {})
        if key in held:
            held[key]["keep_here"] = True
        else:
            try:
                st = p.stat()
                mtime, size = st.st_mtime, st.st_size
            except OSError:
                mtime, size = time.time(), 0
            held[key] = {
                "path": key,
                "filename": p.name,
                "size": size,
                "mtime": mtime,
                "first_seen": time.time(),
                "release_at": float("inf"),
                "hold_days": DEFAULT_HOLD_DAYS,
                "planned_dest": "",
                "makerworld_meta": {},
                "keep_here": True,
            }
        write_state(state)
    logging.info("3MF permanently retained in Downloads: %s", p.name)
    return True


def remove_held(path: Path | str) -> None:
    key = str(Path(path).resolve())
    with state_lock():
        state = read_state()
        held = state.get("held", {})
        if key in held:
            del held[key]
            write_state(state)


def file_now(path: Path | str, config: dict | None = None) -> Path | None:
    """User chosen override: immediately file this .3mf file to its planned destination.

    The hold is only removed once the move has succeeded; if it fails the file keeps
    its hold (and its scheduled release) so nothing is forgotten.
    """
    p = Path(path).resolve()
    key = str(p)
    dest_target: Path | None = None

    with state_lock():
        state = read_state()
        rec = state.get("held", {}).get(key)
        if rec and rec.get("planned_dest"):
            dest_target = Path(rec["planned_dest"])

    if not p.exists():
        remove_held(p)
        return None

    if dest_target is None:
        cfg = config if config is not None else sorter.load_config()
        dest_target = sorter.sort_destination(p, cfg)

    try:
        dest_target.parent.mkdir(parents=True, exist_ok=True)
        final_dest = safe_ops.move(p, dest_target, batch_id="file_now", settle_seconds=0.0)
    except Exception as exc:
        logging.error("Failed executing 'File Now' for %s: %s", p, exc)
        return None
    remove_held(p)
    logging.info("3MF 'File Now' completed: %s -> %s", p.name, final_dest)
    return final_dest


def _folder_is_away(path: Path, config: dict) -> bool:
    """True when ``path`` is inside the folder being sorted and that folder is not there right now.

    A file on a drive that is not plugged in does not exist either, but it is not gone: it is
    back with the drive, and its hold (a "Keep here" choice too) must not be forgotten for that.
    A hold whose file is gone from a folder that is there is dropped, as it always was.
    """
    try:
        root = sorter.watch_root(config)
        try:
            there = root.is_dir()
        except OSError:  # a folder that cannot be looked at is not there for this purpose
            there = False
        return not there and sorter.is_under(path, root)
    except (OSError, ValueError):
        return False


def check_releases(
    config: dict,
    now: float | None = None,
) -> list[tuple[Path, Path]]:
    """Scan held files and return list of (src, planned_dest) that are ready for sorting."""
    hold_cfg = config.get("hold", {})
    if not hold_cfg.get("enabled", True):
        return []

    cur_time = time.time() if now is None else float(now)
    slicers = hold_cfg.get("slicers", DEFAULT_SLICERS)
    slicer_active = is_slicer_running(slicers)

    ready: list[tuple[Path, Path]] = []
    to_delete: list[str] = []
    to_update: dict[str, dict] = {}

    with state_lock():
        state = read_state()
        held = state.get("held", {})

        for key, rec in list(held.items()):
            p = Path(key)
            if not p.exists():
                if not _folder_is_away(p, config):
                    to_delete.append(key)
                continue

            if rec.get("keep_here"):
                continue

            try:
                st = p.stat()
                cur_mtime = st.st_mtime
            except OSError:
                continue

            # If the user or Bambu Studio edited the file, push out the grace period
            recorded_mtime = float(rec.get("mtime", 0))
            if abs(cur_mtime - recorded_mtime) > 2.0:
                hold_days = float(rec.get("hold_days", DEFAULT_HOLD_DAYS))
                rec["mtime"] = cur_mtime
                rec["release_at"] = cur_mtime + (hold_days * 86400.0)
                to_update[key] = rec
                logging.debug("File modification detected on %s; resetting hold period", p.name)
                continue

            release_at = float(rec.get("release_at", 0))
            if cur_time < release_at:
                continue

            # File has reached release age; check lock & slicer
            if not safe_ops.can_open_exclusive(p):
                # File is currently opened by Bambu Studio or another app; defer
                logging.debug("Held file %s is currently locked by a process; deferring", p.name)
                continue

            # If slicer is running, allow up to 7 extra days deferral before overriding
            max_defer = release_at + (7 * 86400.0)
            if slicer_active and cur_time < max_defer:
                logging.debug("Slicer process active; deferring move for %s", p.name)
                continue

            planned = Path(rec.get("planned_dest", ""))
            if not planned or str(planned) == ".":
                planned = sorter.sort_destination(p, config)

            # The record stays until the caller reports a successful move
            # (remove_held) or a failure (release_failed).
            ready.append((p, planned))

        if to_delete or to_update:
            for k in to_delete:
                held.pop(k, None)
            for k, val in to_update.items():
                held[k] = val
            write_state(state)

    return ready


RELEASE_RETRY_SECONDS = 3600.0


def release_failed(path: Path | str, error: object = "", retry_seconds: float = RELEASE_RETRY_SECONDS) -> None:
    """Keep a hold whose release move failed, and try again after ``retry_seconds``."""
    key = str(Path(path).resolve())
    with state_lock():
        state = read_state()
        rec = state.get("held", {}).get(key)
        if not rec:
            return
        rec["release_failures"] = int(rec.get("release_failures", 0)) + 1
        rec["last_release_error"] = str(error)
        rec["release_at"] = time.time() + float(retry_seconds)
        try:
            rec["mtime"] = Path(key).stat().st_mtime
        except OSError:
            pass
        write_state(state)


def get_held_summary() -> dict:
    with state_lock():
        state = read_state()
        held = state.get("held", {})
        active = [r for r in held.values() if not r.get("keep_here")]
        kept = [r for r in held.values() if r.get("keep_here")]
        next_rel = min([r["release_at"] for r in active], default=None)
        return {
            "total_held": len(active),
            "kept_here": len(kept),
            "next_release_at": next_rel,
            "next_release_str": time.strftime("%Y-%m-%d %H:%M", time.localtime(next_rel)) if next_rel else "None",
        }


def prune_missing() -> int:
    pruned = 0
    with state_lock():
        state = read_state()
        held = state.get("held", {})
        for key in list(held.keys()):
            if not Path(key).exists():
                del held[key]
                pruned += 1
        if pruned:
            write_state(state)
    return pruned


def main(argv: list[str] | None = None) -> int:
    import about

    if about.handle_version_flag(argv):
        return 0
    print(about.version_string())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

